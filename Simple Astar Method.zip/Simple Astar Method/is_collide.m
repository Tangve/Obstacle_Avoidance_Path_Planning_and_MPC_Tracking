function y = is_collide(node,obst_map,margin)
obst_num = size(obst_map,1);
for i=1:obst_num
    obst_center = [obst_map(i,1),obst_map(i,2)];
    if norm(node-obst_center,2) <= obst_map(i,3) + margin
        y = logical(1);
        return
    else
        y = logical(0);
    end

end
end