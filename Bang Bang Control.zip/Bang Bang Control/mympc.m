%MPC solver
function [u] = mympc(A,B,Q,R,P,N,umin,umax,xmin,xmax,x,Ts)
[A_hat,B_hat,Q_hat,R_hat]=sysbasis(A,B,Q,R,P,N,Ts);
[G,E,w] = wholeconstraint(A,B,Q,R,P,N,umin,umax,xmin,xmax);
H=2*(B_hat'*Q_hat*B_hat+R_hat);
H=(H+H')/2;
F=2*A_hat'*Q_hat*B_hat;
u=quadprog(H,F'*x,G,w+E*x);
end
