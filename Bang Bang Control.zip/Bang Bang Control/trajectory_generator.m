function q_des = trajectory_generator(t, total_time, path)
total_len = 0;
seg_len = zeros(1,size(path,1)-1);
ts = zeros(1,size(path,1));ts(1)=0;
for i=1:size(path,1)-1
   seg_len(i) = norm(path(i+1,:)-path(i,:),2);
   total_len = total_len + seg_len(i);
end

for i=2:size(path,1)
   ts(i) = ts(i-1) + double(total_time*seg_len(i-1)/total_len); 
end

if t >= total_time
    pos = path(end,:);
    theta = 0;
else
    k = find(ts<=t);
    k = k(end);
    from_node = path(k,:);
    to_node = path(k+1,:);
    theta = atan2(to_node(2)-from_node(2),to_node(1)-from_node(1));
    v_avg = total_len/total_time;
    if (t-ts(k))<eps
        pos = path(k,:);
    else
        pos = path(k,:) + [cos(theta),sin(theta)]*v_avg*(t-ts(k));
    end
end
q_des = [pos,theta];
end