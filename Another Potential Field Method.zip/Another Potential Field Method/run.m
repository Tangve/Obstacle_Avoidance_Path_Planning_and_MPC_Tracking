%
% PotentialFieldScript.m
%

%% Generate some points
clear;
clc;
nrows = 400;
ncols = 600;

obstacle = false(nrows, ncols);

[x, y] = meshgrid (1:ncols, 1:nrows);

%% Generate some obstacle

obstacle (150:end, 100:101) = true;
obstacle (150:200, 400:500) = true;

circ = ((x - 200).^2 + (y - 50).^2) < 50^2;
obstacle(circ) = true;

circ = ((x - 400).^2 + (y - 300).^2) < 100^2;
obstacle(circ) = true;

%% Compute distance transform

d = bwdist(obstacle);

% Rescale and transform distances

d2 = (d/100) + 1;

d0 = 1.5;
nu = 800;

repulsive = nu*((1./d2 - 1/d0).^2);

repulsive (d2 > d0) = 0;


%% Display repulsive potential

figure;
m = mesh (repulsive);
m.FaceLighting = 'phong';
axis equal;

title ('Repulsive Potential');

%% Compute attractive force

goal = [400, 50];

xi = 1/700;

attractive = xi * ( (x - goal(1)).^2 + (y - goal(2)).^2 );

figure;
m = mesh (attractive);
m.FaceLighting = 'phong';
axis equal;

title ('Attractive Potential');

%% Display 2D configuration space

figure;
imshow(~obstacle);

hold on;
plot (goal(1), goal(2), 'r.', 'MarkerSize', 25);
hold off;

axis ([0 ncols 0 nrows]);
axis xy;
axis on;

xlabel ('x');
ylabel ('y');

title ('Configuration Space');

%% Combine terms

f = attractive + repulsive;

figure;
m = mesh (f);
m.FaceLighting = 'phong';
axis equal;

title ('Total Potential');

%% Plan route
start = [50, 350];

route = GradientBasedPlanner (f, start, goal, 1000);

%% Plot the energy surface

figure;
m = mesh (f);
axis equal;

%% Plot ball sliding down hill

[sx, sy, sz] = sphere(20);

scale = 20;
sx = scale*sx;
sy = scale*sy;
sz = scale*(sz+1);

hold on;
p = mesh(sx, sy, sz);
p.FaceColor = 'red';
p.EdgeColor = 'none';
p.FaceLighting = 'phong';
hold off;

% for i = 1:size(route,1)
%     P = round(route(i,:));
%     z = f(P(2), P(1));
%     
%     p.XData = sx + P(1);
%     p.YData = sy + P(2);
%     p.ZData = sz + f(P(2), P(1));
%     
%     drawnow;
%     
%     drawnow;
%     
% end

%% quiver plot
figure;
[gx, gy] = gradient (-f);
skip = 20;

xidx = 1:skip:ncols;
yidx = 1:skip:nrows;
% 
quiver (x(yidx,xidx), y(yidx,xidx), gx(yidx,xidx), gy(yidx,xidx), 0.4);
axis ([1 ncols 1 nrows]);
title("Potential Function Path Planning");

%% Bot plot
global hhh
total_time = 10;
Ts=0.1; % sampling time
Q_actual =[];Q_dest=[];

InitGrafic;
rectangle('Position',[100 150 1 250],'FaceColor','k');
hold on;
rectangle('Position',[400 150 100 50],'FaceColor','k');
hold on;
rectangle('Position',[200-50,50-50,2*50,2*50],'Curvature',[1,1], 'FaceColor','k');
hold on;
rectangle('Position',[400-100,300-100,2*100,2*100],'Curvature',[1,1], 'FaceColor','k');
hold on;
hold on;
plot(start(1), start(2), 'r.', 'MarkerSize', 30);
hold on;
plot(goal(1), goal(2), 'g.', 'MarkerSize', 30);
hold on;
comet(route(:,1),route(:,2),0.01);

N = 20;
x0=double([-30;8;0.2]);
PlotX = [start(1),start(2),0]' + x0;
for t=0:Ts:total_time
    Q_actual = [Q_actual;PlotX'];
    q = double(trajectory_generator(t, total_time, route));
    [Input,Ploterro,PlotX] = my_mpc_tracking(x0,N,q,t,t+Ts);
    Q_dest = [Q_dest;[goal(1),goal(2)]];
    DrawRobot(PlotX',1);
    set(hhh(3),'XData',Q_actual(:,1),'YData',Q_actual(:,2));
    set(hhh(5),'XData',Q_dest(:,1),'YData',Q_dest(:,2));
    pause(0.01);
    drawnow;
    x0 = double(PlotX - q');
end

%% Function
function DrawRobot(Xr,tip)  % draw robot shape
global hhh
P=[1 4 4 -4 -4 -1 -1 -4 -4 4 4 1 1;...  
   3 3 4 4 3 3 -3 -3 -4 -4 -3 -3 3]*3;         

theta = Xr(3); 
R=[cos(theta) -sin(theta); sin(theta) cos(theta)];
T=repmat([Xr(1);Xr(2)],1,size(P,2)) ;

P=R*P+T; 
set(hhh(tip),'XData',P(1,:),'YData',P(2,:));
end

function InitGrafic()
global hhh
figure() ;clf;
hold on;
zoom on;
title('MPC Control Tracking');xlabel('x (m)');ylabel('y (m)');

hhh(1)=plot(0,0,'b') ;
hhh(3)=plot(0,0,'k','LineWidth',1.8) ;
hhh(5)=plot(0,0,'*r') ; 

hold off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end