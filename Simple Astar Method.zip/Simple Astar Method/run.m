clear;
clc;
%% Initialize map
global hhh
xdim = 120;
ydim = 120;

obst_num = 40;
obst_map = zeros(obst_num,3);

start_x = 6;
start_y = 2;
dest_x = 110;
dest_y = 80;

radius = 0.6;
margin = 0.8;

M = zeros(ceil(sqrt(obst_num)),ceil(sqrt(obst_num)));
max_obst_rad = 0.5*(min(abs(dest_x-start_x),abs(dest_y-start_y))/ceil(sqrt(obst_num))-margin);

for i=1:obst_num
[x_location,y_location] = ind2sub(size(M),i);
obst_map(i,:)=[start_x+(max_obst_rad+margin)*(2*x_location+1)...
    ,start_y+(max_obst_rad+margin)*(2*y_location+1)...
    ,max_obst_rad*rand(1)];
end



%% Generate path
node = [start_x,start_y];
path = [start_x,start_y];
c = 1;
num_kids = 6;
while true

    vector = [dest_x-node(1),dest_y-node(2)];
    if norm(vector,2)<0.6 || c > 10000
        break;
    else
        new_node = node + radius*vector/norm(vector,2);
        if is_collide(new_node,obst_map,margin)
            test_node = zeros(num_kids,2);
            theta = atan2(vector(2),vector(1));
            
            for k=1:num_kids
                test_node(k,:) = node + radius*[cos(theta+2*k*pi/num_kids),...
                    sin(theta+2*k*pi/num_kids)];
            end
            
            k = 1;
            distance_array = Inf(num_kids,2);
            while k <= num_kids-1
                if is_collide(test_node(k,:),obst_map,margin)
                    k = k + 1;
                    continue;
                else
                    distance = sqrt((dest_x-test_node(k,1))^2+(dest_y-test_node(k,2))^2);
                    distance_array(k,:)=[distance,k];
                    if distance < 0.2
                        break
                    end
                    k = k + 1;
                end
            end
            [~,Index]=min(distance_array(:,1));
            node = test_node(distance_array(Index,2),:);
        else
            node = new_node;
        end
    end
    c = c + 1;
    path = [path;node];
end
path = simplify_path(obst_map,path,margin);

%% Control
speed = 3;
path_len = sum(sqrt(sum((path(2:end, :) - path(1:end-1,:)).^2,2)));
total_time = path_len/speed;
 
% R_wheel = 0.04;
% L_axis = 0.08;
% 
% vt=R_wheel/2*(wR+wL);
% wt=R_wheel/L_axis*(wR-wL);
% 
% q(1)=q(1) + Ts*vt*cos( q(3) + Ts*wt/2 );
% q(2)=q(2) + Ts*vt*sin( q(3) + Ts*wt/2 );
% q(3)=q(3) + Ts*wt;
% q(3)=wrapToPi(q(3));

%% Plot Trajectory
Ts=0.5; % sampling time
q = [start_x,start_y,0];
Q =[];Q_dest=[];
InitGrafic;
for i = 1:obst_num
x = obst_map(i,1);
y = obst_map(i,2);
r = obst_map(i,3);

rectangle('Position',[x-r,y-r,2*r,2*r],...
  'Curvature',[1,1], 'FaceColor','k');
axis square;
hold on;
end
hold on;
x = start_x;
y = start_y;
r = 0.8;
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
plot(xunit, yunit,'g');
hold on;
x = dest_x;
y = dest_y;
r = 0.8;
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
plot(xunit, yunit,'b');
hold on;
comet(path(:,1),path(:,2),0.01);

N = 20;
x0=[-2;6;0.2];PlotX = x0+q';

for t=0:Ts:total_time
    Q = [Q;PlotX'];
    q = trajectory_generator(t, total_time, path);
    [Input,Ploterro,PlotX] = my_mpc_tracking(x0,N,q,t,t+Ts);
    Q_dest = [Q_dest;[dest_x,dest_y]];
    DrawRobot(PlotX',1);
    set(hhh(3),'XData',Q(:,1),'YData',Q(:,2));
    set(hhh(5),'XData',Q_dest(:,1),'YData',Q_dest(:,2));
    pause(0.01);
    drawnow;
    x0 = PlotX - q';
end


%% Function
function DrawRobot(Xr,tip)  % draw robot shape
global hhh
P=[1 4 4 -4 -4 -1 -1 -4 -4 4 4 1 1;...  
   3 3 4 4 3 3 -3 -3 -4 -4 -3 -3 3]*.15;         

theta = Xr(3); 
R=[cos(theta) -sin(theta); sin(theta) cos(theta)];
T=repmat([Xr(1);Xr(2)],1,size(P,2)) ;

P=R*P+T; 
set(hhh(tip),'XData',P(1,:),'YData',P(2,:));
end

function InitGrafic()
global hhh
figure(10) ;clf ; 
hold on;
zoom on;
title('Robot with differential drive');xlabel('x (m)');ylabel('y (m)');

hhh(1)=plot(0,0,'b') ;     % dejanski robot 
hhh(3)=plot(0,0,'k','LineWidth',1.8) ;  % dejanska pot
hhh(5)=plot(0,0,'*r') ;   % referen�na pot 

hold off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end