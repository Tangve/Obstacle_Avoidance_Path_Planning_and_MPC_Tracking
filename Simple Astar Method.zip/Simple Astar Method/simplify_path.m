function simp_path = simplify_path(obst_map, path, margin)

orig_path = path;

% handle diagional case
path = path(1:2:end, :);

% check collinear
i = 1;flag = 1;
while flag == 1
    while 1
        rm_pts = logical(zeros(size(path,1),1));
        if i >= size(path,1)-3
            flag = 0;
            break;
        elseif abs(atan2(path(i+1,2)-path(i,2),path(i+1,1)-path(i,1))-...
            atan2(path(i+2,2)-path(i,2),path(i+2,1)-path(i,1)))<10^(-4)
            rm_pts(i+1) = 1;
            path = path(~rm_pts,:);
        else
            break;
        end
    end
    i = i + 1;
end


% add start/goal points
if any(path(1,:) ~= orig_path(1,:))
    path = [orig_path(1,:); path];
end
if any(path(end,:) ~= orig_path(end,:))
    path = [path; orig_path(end,:)];
end

path0 = path;

for i=1:(size(path,1)-1)
    for j = (i+1):size(path,1)
        no_collide = 1;
        for k = 1:size(obst_map,1)
            A = path(j,2) - path(i,2);
            B = - path(j,1) + path(i,1);
            if abs(A*obst_map(k,1)+B*obst_map(k,2)+path(j,1)*path(i,2)-path(i,1)*path(j,2))<obst_map(k,3)
                no_collide = 0;
                break;
            end
        end
        if no_collide == 1
            path(j,:) = path(i,:);
        else
            path(j-1,:) = path0(j-1,:);
            path(j,:) = path0(j,:);
            break;
        end
    end
end

% remove duplicated points:
rm_pts = logical(zeros(size(path,1),1));
for i = 1:size(path,1)-1
    if norm(path(i+1,:) - path(i,:)) < 1e-3
        rm_pts(i) = 1;
    end
end
path = path(~rm_pts,:);

% add goal points
if any(path(end,:) ~= orig_path(end,:))
    path = [path; orig_path(end,:)];
end

simp_path = path;
end