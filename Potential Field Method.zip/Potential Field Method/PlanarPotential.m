clear;
clc;
%% Initialize map
global obst_num obst_map center R
xdim = 120;
ydim = 120;
center = [xdim/2,ydim/2];
R = norm(center,2);

obst_num = 3;
obst_map = zeros(obst_num,3);

start_x = 6;
start_y = 2;
dest_x = 110;
dest_y = 90;
start_node = [start_x,start_y];
dest_node = [dest_x,dest_y];

obst_map(1,:) = [65,90,10];
obst_map(2,:) = [83.5,40,20];
obst_map(3,:) = [10,40,10];

%% Optimize path
k = 2.5;
step = 0.5;
f = zeros(xdim/step + 1,ydim/step + 1);
for x = 0:step:xdim
    for y = 0:step:ydim
        if iswithin(x,y)
            f(1+int16(x/step),1+int16(y/step))=1;
        elseif abs(x)<eps || abs(y)<eps || abs(xdim-x)<eps || abs(ydim-y)<eps
            f(1+int16(x/step),1+int16(y/step))=1;
        else
            f(1+int16(x/step),1+int16(y/step))...
        = gamma(1,[x,y],dest_node)/(gamma(k,[x,y],dest_node) + beta_all([x,y]))^(1/k);
        end
    end
end

node = start_node;
path = start_node;
c = 1;

while 1
    if norm(node-dest_node,2)<eps || c>10000
        break;
    end
    if abs(node(1))<eps && abs(node(2))<eps
        node = [node(1)+step,node(2)+step];
    elseif abs(node(1))<eps && abs(ydim-node(2))<eps
        node = [node(1)+step,node(2)-step];
    elseif abs(xdim-node(1))<eps && abs(node(2))<eps
        node = [node(1)-step,node(2)+step];
    elseif abs(xdim-node(1))<eps && abs(ydim-node(2))<eps
        node = [node(1)-step,node(2)-step];
    elseif abs(node(1))<eps
        node = [node(1)+step,node(2)];
    elseif abs(node(2))<eps
        node = [node(1),node(2)+step];
    elseif abs(xdim-node(1))<eps
        node = [node(1)-step,node(2)];
    elseif abs(ydim-node(2))<eps
        node = [node(1),node(2)-step];
    else
        is_continue = logical(1);
        matrix = f(int16(node(1)/step):2+int16(node(1)/step),...
            int16(node(2)/step):2+int16(node(2)/step));
        while is_continue
            is_continue = logical(0);
            
            Min = min(matrix,[],'all');
            [row,col] = find(abs(matrix-Min)<eps,1);
            if size(path,1) > 2
                for i=1:size(path,1)
                    if norm(node + [(row-2)*step,(col-2)*step]-path(1+end-i,:))<eps
                        matrix(row,col) = Inf;
                        is_continue = logical(1);
                    end
                end
            end
        end
    end
    node = node + [(row-2)*step,(col-2)*step];
    c = c + 1;
    path = [path;node];
    
        
end

f = f';

x = 0:step:xdim;
y = 0:step:ydim;
[X,Y]=meshgrid(x,y);
figure;
surf(X,Y,f);
title('Total Potential');

%% Plot path
figure(2);
x = start_node(1);
y = start_node(2);
r = 0.8;
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
plot(xunit, yunit,'g');
hold on;

x = dest_node(1);
y = dest_node(2);
r = 0.8;
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
plot(xunit, yunit,'b');
hold on;

for i = 1:obst_num
x = obst_map(i,1);
y = obst_map(i,2);
r = obst_map(i,3);

rectangle('Position',[x-r,y-r,2*r,2*r],...
  'Curvature',[1,1], 'FaceColor','k');
axis square;
hold on;
end
plot(path(:,1),path(:,2),'k','LineWidth',0.8);
title('Simple Potential Function Path Planning')
axis equal;
grid on;

%% Functions
function boo = iswithin(x,y)
    global obst_num obst_map
    boo = logical(0);
    for i = 1:obst_num
        node = [x,y];
        obstacle_center = [obst_map(i,1),obst_map(i,2)];
        radius = obst_map(i,3);
        distance = norm(node - obstacle_center,2);
        if radius>distance
            boo = logical(1);
            return;
        end
    end
        
        
end
function y = gamma(k,node,dest_node)
y = (norm(dest_node-node,2))^(2*k);
end

function y = beta(i,node)
global obst_map center R
if i == 0
    radius = R;
    distance = norm(node-center,2);
    y = radius.^2-distance.^2;
    return;
else
    obstacle_center = [obst_map(i,1),obst_map(i,2)];
    radius = obst_map(i,3);
    distance = norm(node - obstacle_center,2);
    y = distance.^2 - radius.^2;
    return;
end
end

function y = beta_all(node)
global obst_num

y = 1;
i = 0;
while i < obst_num + 1
    y = y * beta(i,node);
    i = i + 1;
end
end