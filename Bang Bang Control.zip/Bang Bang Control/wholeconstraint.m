%The constraints
function [G,E,w] = wholeconstraint(A,B,Q,R,P,N,umin,umax,xmin,xmax)
[A_hat,B_hat,Q_hat,R_hat]=sysbasis(A,B,Q,R,P,N);
%form E
dim=length(A);
E1=zeros(2*N*length(umin),length(A));
E=[E1;A_hat;-A_hat];
%form w
w1=kron(ones(N,1),umax);
w2=kron(ones(N,1),-umin);
w3=[kron(ones(N,1),-xmin);[2;1;pi/2]];
w4=[kron(ones(N,1),xmax);[2;1;pi/2]];
w=[w1;w2;w3;w4];
%form G
G1=kron(eye(N),eye(length(umax)));
G2=kron(eye(N),-eye(length(umin)));
G3=-B_hat;
G4=B_hat;
G=[G1;G2;G3;G4];
end