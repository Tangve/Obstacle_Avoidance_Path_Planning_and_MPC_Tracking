function [Input,Ploterro,PlotX] = my_mpc_tracking(x0,N,node,t_pre,t_now)
%% system
Ts=0.1;
A=eye(3)+Ts.*[0,0,0;0,0,2;0,0,0];
B=Ts.*[1,0;0,0;0,1];
R=0.2.*eye(2);
Q=0.5.*eye(3);
P=0.5.*eye(3);

umin=[-2;-pi/2];
umax=[5;pi/2];
xminT=[-2;-1;-pi/2];
xmaxT=[2;1;pi/2];
% xmin=[-400;-400;-pi];
% xmax=[400;400;pi];

X_state=x0;
%% Plot


U_optimal=[];
PlotX=[];
Plotdes=[];
Ploterro=[];

for i=t_pre:(t_now-t_pre)/3:t_now
    Cos=abs(cos(node(3)));
    Sin=abs(sin(node(3)));
    xmin=[Cos*(-610+node(1))+Sin*(-410+node(2));Sin*(-610+node(1))+Cos*(-410+node(2));-pi];
    xmax=[Cos*(610+node(1))+Sin*(410+node(2));Sin*(610+node(1))+Cos*(410+node(2));pi];
    u=mympc(A,B,Q,R,P,N,umin,umax,xmin,xmax,x0,Ts);
    U_optimal=[U_optimal,u(1:2,:)];
    x0=A*x0+B*u(1:2,:);
    X_state=[X_state,x0];
end
X_des=node(1);
Y_des=node(2);
Theta_des=node(3);
Ploterro=x0;
PlotX=[X_des+x0(1);Y_des+x0(2);Theta_des+x0(3)];
u=U_optimal(2,length(U_optimal));
v=2*cos(u)+U_optimal(2,length(U_optimal));
Input=[v;u];
end

