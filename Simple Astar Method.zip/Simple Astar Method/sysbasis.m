%system basic information
function [A_hat,B_hat,Q_hat,R_hat] = sysbasis(A,B,Q,R,P,N,Ts)
%form A
dim=length(A);
A_hat=eye(dim);
for k=1:N
    a=A^k;
    A_hat=[A_hat;a];
end
% form B
B_use=[];
for j=N-1:-1:0
    Sj=[];
    for i=0:j
        sj=(A^i)*B;
        Sj=[Sj;sj];
    end
    ling=zeros(dim*(N-1-j),2);
    Sj=[ling;Sj];
    B_use=[B_use,Sj];
end
B_hat=[zeros(dim,2*N);B_use];
%form Q
Q_hat=kron(eye(N),0.1.*Q);
Q_hat=blkdiag(Q_hat,P);
%form R
R_hat=kron(eye(N),0.1.*R);
end

